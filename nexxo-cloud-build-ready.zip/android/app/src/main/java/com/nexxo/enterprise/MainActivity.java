package com.nexxo.enterprise;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
