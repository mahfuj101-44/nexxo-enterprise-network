# NEXXO Enterprise Network — Cloud APK Build

This project is prepared for a direct Android APK build without Android Studio.

## Build

1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build NEXXO Android APK**.
4. Click **Run workflow**.
5. Wait for the workflow to finish.
6. Open the completed workflow run.
7. Download the artifact named **NEXXO-Enterprise-Network-debug-APK**.
8. Inside the downloaded artifact, install `app-debug.apk` on an Android phone.

The workflow installs Java 21 and Android SDK API 36, builds the existing web app, synchronizes Capacitor, and generates the debug APK.

## Important

- This is a DEBUG APK for testing, not the final signed release APK.
- Do not put a private keystore/password in the repository.
- A signed release APK will be prepared later after the app passes real-device testing.
